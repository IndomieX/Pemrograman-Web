<!DOCTYPE html>
<html>
<head>
  <title>Form Penilaian Mahasiswa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5 px-5">
  <div class="card shadow-sm">
    <div class="card-header bg-primary text-white">
      <h4 class="text-center mb-0">Form Penilaian Mahasiswa ITPLN</h4>
    </div>
    <div class="card-body">

<?php
// Inisialisasi variabel awal (kosongin semua input dan error)
$error = "";
$nama = $nim = $absen = $tugas = $uts = $uas = "";

// Cek apakah tombol "Proses" diklik
if (isset($_POST['proses'])) {
    // Ambil dan bersihkan inputan dari form
    $nama   = trim($_POST['nama']);
    $nim    = trim($_POST['nim']);
    $absen  = $_POST['absen'];
    $tugas  = $_POST['tugas'];
    $uts    = $_POST['uts'];
    $uas    = $_POST['uas'];

    // Validasi input kosong
    if ($nama == "" || $nim == "" || $absen == "" || $tugas == "" || $uts == "" || $uas == "") {
        $error = "Semua kolom wajib diisi!";
    }
    // Validasi nilai harus dalam rentang 0 - 100
    elseif (
        $absen < 0 || $absen > 100 ||
        $tugas < 0 || $tugas > 100 ||
        $uts < 0 || $uts > 100 ||
        $uas < 0 || $uas > 100
    ) {
        $error = "Nilai harus berada di antara 0 hingga 100!";
    }
}
?>

<!-- FORM INPUT NILAI -->
<form method="POST">
  <!-- Input Nama -->
  <div class="mb-3">
    <label class="fw-bold">Masukkan Nama</label>
    <input class="form-control" name="nama" value="<?= htmlspecialchars($nama) ?>">
  </div>
  
  <!-- Input NIM -->
  <div class="mb-3">
    <label class="fw-bold">Masukkan NIM</label>
    <input class="form-control" name="nim" value="<?= htmlspecialchars($nim) ?>">
  </div>
  
  <!-- Input Kehadiran -->
  <div class="mb-3">
    <label class="fw-bold">Nilai Kehadiran (10%)</label>
    <input class="form-control" name="absen" type="number" placeholder="Untuk Lulus minimal 70%" value="<?= htmlspecialchars($absen) ?>">
  </div>
  
  <!-- Input Tugas -->
  <div class="mb-3">
    <label class="fw-bold">Nilai Tugas (20%)</label>
    <input class="form-control" name="tugas" type="number" placeholder="0 - 100" value="<?= htmlspecialchars($tugas) ?>">
  </div>
  
  <!-- Input UTS -->
  <div class="mb-3">
    <label class="fw-bold">Nilai UTS (30%)</label>
    <input class="form-control" name="uts" type="number" placeholder="0 - 100" value="<?= htmlspecialchars($uts) ?>">
  </div>
  
  <!-- Input UAS -->
  <div class="mb-3">
    <label class="fw-bold">Nilai UAS (40%)</label>
    <input class="form-control" name="uas" type="number" placeholder="0 - 100" value="<?= htmlspecialchars($uas) ?>">
  </div>

  <!-- Tombol Proses -->
  <button type="submit" class="btn btn-primary w-100" name="proses">Proses</button>
</form>

<!-- HASIL PENILAIAN -->
<?php
if (isset($_POST['proses']) && $error == "") {
    // Hitung nilai akhir dengan bobot
    $nilai_akhir = ($absen * 0.1) + ($tugas * 0.2) + ($uts * 0.3) + ($uas * 0.4);

    // Penentuan grade berdasarkan nilai akhir
    if ($nilai_akhir >= 85) $grade = "A";
    elseif ($nilai_akhir >= 70) $grade = "B";
    elseif ($nilai_akhir >= 55) $grade = "C";
    elseif ($nilai_akhir >= 40) $grade = "D";
    else $grade = "E";

    // Penentuan status kelulusan
    if ($nilai_akhir >= 60 && $absen > 70 && $tugas >= 40 && $uts >= 40 && $uas >= 40) {
        $status = "LULUS";
        $warna = "success"; // Warna hijau
    } else {
        $status = "TIDAK LULUS";
        $warna = "danger"; // Warna merah
    }

    // Tampilkan hasil
    echo "
    <div class='card mt-4 border-$warna'>
        <div class='card-header bg-$warna text-white'>Hasil Penilaian</div>
        <div class='card-body'>
            <p><strong>Nama:</strong> $nama</p>
            <p><strong>NIM:</strong> $nim</p>
            <p><strong>Nilai Akhir:</strong> $nilai_akhir</p>
            <p><strong>Grade:</strong> $grade</p>
            <p><strong>Status:</strong> $status</p>
            <a class='btn btn-$warna w-100' href=''>Selesai</a>
        </div>
    </div>";
}
?>

    </div>
  </div>
</div>

<!-- MODAL ERROR (muncul kalau ada error input) -->
<div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-danger">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="errorLabel">Peringatan!</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center">
        <?= $error ?>
      </div>
    </div>
  </div>
</div>

<!-- FOOTER -->
<footer class="text-center mt-5 py-3 bg-light border-top">
  <small>&copy; 202332146_Rafi Daniswara P.W</small>
  <div id="clock" class="text-muted"></div>
</footer>

<!-- Script Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Kalau ada error, munculin modal
  <?php if ($error != ""): ?>
    const modal = new bootstrap.Modal(document.getElementById('errorModal'));
    modal.show();
  <?php endif; ?>

</script>
</body>
</html>
